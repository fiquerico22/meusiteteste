CREATE TABLE public.bella_leads (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 name text NOT NULL CHECK (char_length(name) BETWEEN 2 AND 100),
 email text NOT NULL CHECK (char_length(email) <= 255 AND email ~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$'),
 whatsapp text NOT NULL CHECK (whatsapp ~ '^[0-9]{10,13}$'),
 consent_version text NOT NULL DEFAULT 'leads-v1' CHECK (consent_version = 'leads-v1'),
 accepted boolean NOT NULL CHECK (accepted = true),
 created_at timestamptz NOT NULL DEFAULT now()
);
GRANT INSERT ON public.bella_leads TO anon, authenticated;
GRANT ALL ON public.bella_leads TO service_role;
ALTER TABLE public.bella_leads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Visitors can submit consenting leads" ON public.bella_leads FOR INSERT TO anon, authenticated WITH CHECK (accepted = true);
CREATE TABLE public.bella_ad_consents (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 visitor_id uuid NOT NULL,
 accepted boolean NOT NULL,
 notice_version text NOT NULL CHECK (notice_version = 'meta-v1'),
 created_at timestamptz NOT NULL DEFAULT now()
);
GRANT INSERT ON public.bella_ad_consents TO anon, authenticated;
GRANT ALL ON public.bella_ad_consents TO service_role;
ALTER TABLE public.bella_ad_consents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Visitors can record ad preferences" ON public.bella_ad_consents FOR INSERT TO anon, authenticated WITH CHECK (notice_version = 'meta-v1');