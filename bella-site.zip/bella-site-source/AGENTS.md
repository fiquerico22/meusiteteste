<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the requested sales sections on the index as one scrolling page; privacy has its own route for shareable disclosure.
- Use semantic global design tokens and the fashion Button variants for the Bella Moda presentation.
- Store leads through insert-only RLS with database validation and client Zod validation; no visitor may read captured personal data.
- Keep confirmed social URLs and Pixel ID in bella-config; do not invent brand-owned identifiers.
- Gate Meta tracking with regional consent and append-only choice records; send Lead only after a successful saved contact, never personal form fields.
