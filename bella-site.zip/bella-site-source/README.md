# Bella Moda — site

Landing page de vendas (captura de leads com cupom de 10%).

## Tecnologia

TanStack Start (React 19 + Vite), TypeScript, Tailwind CSS 4. Banco de dados: Postgres/Supabase.

## Rodar localmente

```sh
npm install        # ou: bun install
cp .env.example .env   # e preencha com os dados do seu banco
npm run dev        # abre em http://localhost:8080
```

## Gerar a versão de produção

```sh
npm run build
npm run preview    # testa o resultado do build localmente
```

O build gera a pasta `.output/` (servidor) e `dist/` (arquivos estáticos). Como o site
usa renderização no servidor, o servidor de destino precisa executar o app gerado —
não basta copiar arquivos estáticos.

## Banco de dados

Os cadastros do formulário e as preferências de anúncios ficam em duas tabelas.
O script completo (criação, regras de proteção e permissões) está em:

`drizzle/migrations/0000_bella_leads_and_consent.sql`

Rode esse script no seu Postgres/Supabase antes de publicar, senão o formulário
não consegue salvar. O script já deixa as tabelas protegidas: visitantes só
conseguem enviar um cadastro, nunca ler os dados de outras pessoas.

## Antes de publicar

`src/lib/bella-config.ts` guarda os links e códigos da loja. Os campos
`instagramUrl`, `facebookUrl` e `pixelId` estão vazios — preencha com os dados
oficiais da Bella Moda. Sem o `pixelId`, o rastreamento de anúncios fica desligado.

## Testes

```sh
npm run test
npm run lint
```

## Hospedagem fora da Lovable

Este projeto usa tecnologias abertas (React, TanStack Start, Vite). Para as etapas
recomendadas de publicação em outro provedor, veja o guia oficial de auto-hospedagem:
https://docs.lovable.dev/tips-tricks/self-hosting
