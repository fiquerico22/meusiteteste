import { createFileRoute } from "@tanstack/react-router";
import { BellaPage } from '@/components/bella-page';

export const Route = createFileRoute("/")({
  component: BellaPage,
  head: () => ({ meta: [
    { title: 'Bella Moda | Elegância leve e 10% OFF na primeira compra' },
    { name: 'description', content: 'Moda feminina casual-elegante para acompanhar sua rotina. Conheça a Bella Moda e cadastre-se para ganhar 10% de desconto no primeiro pedido.' },
    { property: 'og:title', content: 'Bella Moda | Feita para ser você' },
    { property: 'og:description', content: 'Peças versáteis, elegância e conforto. Ganhe 10% OFF no seu primeiro pedido.' },
    { property: 'og:type', content: 'website' },
    { property: 'og:url', content: '/' },
    { name: 'twitter:card', content: 'summary_large_image' },
  ], links: [{ rel: 'canonical', href: '/' }], scripts: [{ type: 'application/ld+json', children: JSON.stringify({ '@context': 'https://schema.org', '@type': 'ClothingStore', name: 'Bella Moda', description: 'Moda feminina casual-elegante.', priceRange: '$$', currenciesAccepted: 'BRL' }) }] }),
});
