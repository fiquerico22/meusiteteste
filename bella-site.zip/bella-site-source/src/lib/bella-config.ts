// Business-owned links and Pixel ID must be confirmed before activation.
export const bellaConfig = { instagramUrl: '', facebookUrl: '', pixelId: '', coupon: 'BELLA10' };