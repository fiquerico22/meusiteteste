import { z } from 'zod';

export const leadSchema = z.object({
  name: z.string().trim().min(2, 'Informe seu nome.').max(100),
  email: z.string().trim().email('Confira seu e-mail.').max(255),
  whatsapp: z.string().transform(value => value.replace(/\D/g, '')).pipe(z.string().regex(/^\d{10,13}$/, 'Informe seu WhatsApp com DDD.')),
  accepted: z.literal(true, { errorMap: () => ({ message: 'Autorize o contato para receber seu cupom.' }) }),
});