import { useState, type FormEvent } from 'react';
import { ArrowRight, Check, Copy, LockKeyhole } from 'lucide-react';
import { Link } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { leadSchema } from '@/lib/lead-schema';
import { bellaConfig } from '@/lib/bella-config';

export function LeadCapture() {
  const [status, setStatus] = useState<'idle'|'saving'|'success'>('idle');
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (status === 'saving') return;
    const form = new FormData(event.currentTarget);
    const parsed = leadSchema.safeParse({ name: form.get('name'), email: form.get('email'), whatsapp: form.get('whatsapp'), accepted: form.get('accepted') === 'on' });
    if (!parsed.success) { setError(parsed.error.issues[0]?.message ?? 'Confira seus dados.'); return; }
    setStatus('saving'); setError('');
    try {
      const { error: saveError } = await supabase.from('bella_leads').insert({ ...parsed.data, consent_version: 'leads-v1' });
      if (saveError) throw saveError;
      setStatus('success');
      window.dispatchEvent(new Event('bella-lead-saved'));
    } catch { setStatus('idle'); setError('Não conseguimos salvar seu contato. Tente novamente.'); }
  }
  return <section className="capture section" id="cupom"><div className="wrap capture-grid">
    <div><div className="eyebrow text-rose-ink">Um presente de boas-vindas</div><h2>Seu próximo look.<br />Um carinho a mais.</h2><p className="capture-copy">Entre para o universo Bella Moda e ganhe um cupom exclusivo para sua primeira compra. Porque se sentir bem começa nos detalhes.</p><div className="coupon-amount">10%<span>OFF no primeiro pedido</span></div></div>
    {status === 'success' ? <div className="success-box" role="status"><Check className="mx-auto text-rose-ink" /><h3>Seu cupom está aqui!</h3><p className="form-message">Contato cadastrado. Use este código no seu primeiro pedido:</p><div className="coupon-code">{bellaConfig.coupon}</div><Button variant="fashion" onClick={async () => { try { await navigator.clipboard.writeText(bellaConfig.coupon); setCopied(true); } catch { setError('Selecione e copie o código acima.'); } }}><Copy />{copied ? 'Cupom copiado!' : 'Copiar cupom'}</Button>{error && <p>{error}</p>}</div> :
    <form className="lead-form" onSubmit={submit}><label htmlFor="name">Seu nome<input id="name" name="name" placeholder="Como podemos te chamar?" autoComplete="given-name" maxLength={100} required /></label><label htmlFor="email">E-mail<input id="email" name="email" type="email" placeholder="voce@exemplo.com" autoComplete="email" maxLength={255} required /></label><label htmlFor="whatsapp">WhatsApp com DDD<input id="whatsapp" name="whatsapp" type="tel" placeholder="(11) 99999-9999" autoComplete="tel" maxLength={20} required /></label><label className="consent-label"><input type="checkbox" name="accepted" required /><span>Quero receber o cupom, novidades e ofertas da Bella Moda por e-mail e WhatsApp. Posso cancelar a qualquer momento. Li a <Link to="/privacidade" className="underline">Política de Privacidade</Link>.</span></label><Button variant="fashion" type="submit" disabled={status === 'saving'}>{status === 'saving' ? 'Preparando seu cupom…' : 'Quero meu cupom de 10%'}<ArrowRight /></Button>{error && <p role="alert" className="form-message text-destructive">{error}</p>}<div className="hero-note justify-center text-muted-foreground"><LockKeyhole size={12} />Seus dados protegidos. Seu estilo em primeiro lugar.</div></form>}
  </div></section>;
}