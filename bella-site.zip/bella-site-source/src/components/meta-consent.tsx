import { useEffect, useState } from 'react';
import { Link } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { bellaConfig } from '@/lib/bella-config';

type Pixel = { (...args: unknown[]): void; queue: unknown[][]; callMethod?: (...args: unknown[]) => void; loaded?: boolean; version?: string; push?: Pixel };
declare global { interface Window { fbq?: Pixel; _fbq?: Pixel } }
const storageKey = 'bella-ad-choice';
const consentCountries = new Set(['AT','BE','BG','HR','CY','CZ','DK','EE','FI','FR','DE','GR','HU','IE','IT','LV','LT','LU','MT','NL','PL','PT','RO','SK','SI','ES','SE','IS','LI','NO','GB','CH','BR']);
const noticeVersion = 'meta-v1';
export function MetaConsent() {
 const [visible, setVisible] = useState(false);
 const [error, setError] = useState('');
 const [saving, setSaving] = useState(false);
 useEffect(() => {
   if (!/^\d+$/.test(bellaConfig.pixelId)) return;
   let allowedByRegion = false;
   let alive = true;
   function choice(): boolean | null { try { const raw = localStorage.getItem(storageKey); if (!raw) return null; const value = JSON.parse(raw); return value.version === noticeVersion && typeof value.accepted === 'boolean' ? value.accepted : null; } catch { return null; } }
   function permitted() { const stored = choice(); return stored === true || (stored === null && allowedByRegion); }
   function loadPixel() {
     if (!permitted()) { window.fbq?.('consent','revoke'); return; }
     if (!window.fbq) {
       const pixel: Pixel = Object.assign((...args: unknown[]) => { if (pixel.callMethod) pixel.callMethod(...args); else pixel.queue.push(args); }, { queue: [] as unknown[][] });
       pixel.loaded = true; pixel.version = '2.0'; pixel.push = pixel;
       window.fbq = pixel; window._fbq = pixel;
       pixel('set','autoConfig',false,bellaConfig.pixelId);
       pixel('init',bellaConfig.pixelId);
       const script = document.createElement('script'); script.async = true; script.src = 'https://connect.facebook.net/en_US/fbevents.js'; script.id = 'bella-meta-pixel'; document.head.appendChild(script);
       pixel('consent','grant'); pixel('track','PageView');
     } else window.fbq('consent','grant');
   }
   async function start() {
     if (choice() !== null) { loadPixel(); return; }
     try { const response = await fetch('/cdn-cgi/trace', { signal: AbortSignal.timeout(2000) }); if (!response.ok) throw new Error(); const country = (await response.text()).match(/^loc=([A-Z]{2})$/m)?.[1]; allowedByRegion = Boolean(country && !['XX','T1'].includes(country) && !consentCountries.has(country)); } catch { allowedByRegion = false; }
     if (!alive) return;
     if (allowedByRegion) loadPixel(); else setVisible(true);
   }
   const settings = () => setVisible(true);
   const sync = () => loadPixel();
   const lead = () => { if (permitted() && window.fbq) window.fbq('track','Lead'); };
   window.addEventListener('bella-cookie-settings', settings); window.addEventListener('storage',sync); window.addEventListener('bella-consent-updated',sync); window.addEventListener('bella-lead-saved',lead);
   void start();
   return () => { alive = false; window.removeEventListener('bella-cookie-settings',settings); window.removeEventListener('storage',sync); window.removeEventListener('bella-consent-updated',sync); window.removeEventListener('bella-lead-saved',lead); };
 }, []);
 useEffect(() => {
   if (bellaConfig.pixelId) return;
   const settings = () => { setVisible(true); };
   window.addEventListener('bella-cookie-settings',settings);
   return () => window.removeEventListener('bella-cookie-settings',settings);
 }, []);
 async function save(accepted: boolean) {
   setSaving(true); setError('');
   try {
     let visitor = localStorage.getItem('bella-visitor-id');
     if (!visitor || !/^[0-9a-f-]{36}$/i.test(visitor)) { visitor = crypto.randomUUID(); localStorage.setItem('bella-visitor-id',visitor); }
     if (!accepted) { localStorage.setItem(storageKey, JSON.stringify({accepted,version:noticeVersion})); window.dispatchEvent(new Event('bella-consent-updated')); }
     const {error: saveError} = await supabase.from('bella_ad_consents').insert({visitor_id:visitor,accepted,notice_version:noticeVersion});
     if (saveError) throw saveError;
     localStorage.setItem(storageKey,JSON.stringify({accepted,version:noticeVersion})); window.dispatchEvent(new Event('bella-consent-updated')); setVisible(false);
   } catch { setError('Não foi possível registrar sua escolha. A publicidade permanece bloqueada até o aceite ser salvo.'); } finally { setSaving(false); }
 }
 return visible ? <aside className="cookie-panel" aria-label="Preferências de publicidade"><h3>Sua privacidade importa.</h3><p>{bellaConfig.pixelId ? 'Podemos usar cookies da Meta para medir visitas e cadastros e melhorar nossos anúncios. Você pode recusar ou alterar sua escolha no rodapé.' : 'O Pixel da Meta ainda não está ativo. Você pode registrar sua preferência para quando ele for configurado.'} <Link className="underline" to="/privacidade">Saiba mais</Link>.</p><div className="flex gap-3"><Button variant="fashionOutline" disabled={saving} onClick={()=>void save(false)}>Recusar</Button><Button variant="fashion" disabled={saving} onClick={()=>void save(true)}>Aceitar</Button></div>{error && <p role="alert" className="mt-3">{error}</p>}</aside> : null;
}