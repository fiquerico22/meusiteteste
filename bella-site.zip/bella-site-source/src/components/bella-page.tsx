import { useState } from 'react';
import { Link } from '@tanstack/react-router';
import { ArrowRight, Instagram, ShieldCheck, LockKeyhole, Heart, Leaf, Ruler, MessageCircle, Star, Plus, Minus, Check, Copy, Facebook } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { LeadCapture } from '@/components/lead-capture';
import { bellaConfig } from '@/lib/bella-config';
import hero from '@/assets/bella-hero.webp';
import p1 from '@/assets/product-1.webp';
import p2 from '@/assets/product-2.webp';
import p3 from '@/assets/product-3.webp';
import p4 from '@/assets/product-4.webp';
import p5 from '@/assets/product-5.webp';
import p6 from '@/assets/product-6.webp';

const products = [
  { name: 'Blusa acetinada Aurora', price: 'R$ 189,00', detail: 'Leveza que acompanha você', image: p1, tag: 'Essencial' },
  { name: 'Calça alfaiataria Serena', price: 'R$ 259,00', detail: 'Elegância em cada movimento', image: p2, tag: 'Queridinha' },
  { name: 'Vestido midi Florença', price: 'R$ 289,00', detail: 'Do café ao jantar', image: p3, tag: 'Novo' },
  { name: 'Blazer de linho Essência', price: 'R$ 329,00', detail: 'Um toque de sofisticação', image: p4, tag: '' },
  { name: 'Camisa de linho Brisa', price: 'R$ 219,00', detail: 'Naturalmente atemporal', image: p5, tag: '' },
  { name: 'Regata canelada Luna', price: 'R$ 149,00', detail: 'O básico nada básico', image: p6, tag: '' },
];
const testimonials = [
  { quote: 'Finalmente encontrei peças que me deixam arrumada sem abrir mão do conforto. A calça de alfaiataria virou minha favorita!', name: 'Mariana A.', initials: 'MA', detail: 'Versatilidade no dia a dia' },
  { quote: 'O tecido, o caimento, os detalhes… tudo lindo! O vestido vai do trabalho ao jantar, é só trocar os acessórios.', name: 'Camila R.', initials: 'CR', detail: 'Elegância sem esforço' },
  { quote: 'Fui muito bem atendida e recebi ajuda para escolher meu tamanho. Dá para sentir o carinho em cada detalhe.', name: 'Juliana S.', initials: 'JS', detail: 'Uma experiência especial' },
];
const faqs = [
  ['Como recebo meu cupom de 10%?', 'Preencha seu nome, e-mail e WhatsApp no formulário e autorize o contato. Seu cupom aparece na tela assim que o cadastro for concluído.'],
  ['Como posso usar o cupom?', 'Apresente o código BELLA10 ao fazer seu primeiro pedido com a Bella Moda. Confirme com o atendimento as condições aplicáveis antes de concluir a compra.'],
  ['Como escolher o tamanho ideal?', 'Peça ao atendimento as medidas da peça que você gostou. Compare com uma roupa que já veste bem e tire suas dúvidas sobre o caimento antes de comprar.'],
  ['Como funcionam a entrega e as trocas?', 'Os prazos, valores de entrega e condições de troca devem ser confirmados com o atendimento antes do pedido. Compras online têm direito de arrependimento em até 7 dias após o recebimento, conforme o CDC.'],
  ['Vou receber muitas mensagens?', 'Usaremos seu e-mail e WhatsApp para compartilhar o cupom, novidades e ofertas autorizadas. Você pode pedir o cancelamento pelo mesmo canal, a qualquer momento.'],
];
export function BellaHeader() {
  return <><div className="announcement">Um novo jeito de se sentir você. <strong>10% OFF na primeira compra</strong> <span aria-hidden="true">♡</span></div><header className="wrap site-header"><Link to="/" className="wordmark" aria-label="Bella Moda, início">bella moda<span>FEITA PARA SER VOCÊ</span></Link><nav className="nav-links" aria-label="Navegação principal"><a href="/#colecao">Nossa coleção</a><a href="/#essencia">Nossa essência</a><a href="/#duvidas">Dúvidas frequentes</a></nav><Button variant="fashion" asChild><a href="/#cupom">Quero meu cupom<ArrowRight /></a></Button></header></>;
}
export function BellaFooter() {
 const [notice, setNotice] = useState('');
 return <footer className="footer"><div className="wrap"><div className="footer-top"><div><Link to="/" className="wordmark">bella moda<span>FEITA PARA SER VOCÊ</span></Link><p className="mt-4 text-[10px] opacity-70">Elegância leve. Beleza de verdade.</p></div><div className="flex gap-2"><Button variant="ghost" size="icon" aria-label="Instagram da Bella Moda" onClick={() => bellaConfig.instagramUrl ? window.open(bellaConfig.instagramUrl, '_blank', 'noopener,noreferrer') : setNotice('O perfil oficial do Instagram será divulgado em breve.')}><Instagram /></Button><Button variant="ghost" size="icon" aria-label="Facebook da Bella Moda" onClick={() => bellaConfig.facebookUrl ? window.open(bellaConfig.facebookUrl, '_blank', 'noopener,noreferrer') : setNotice('O perfil oficial do Facebook será divulgado em breve.')}><Facebook /></Button></div></div>{notice && <p role="status" className="text-xs mb-5">{notice}</p>}<div className="footer-bottom"><span>© 2026 Bella Moda. Todos os direitos reservados.</span><div className="flex gap-6"><Link to="/privacidade">Política de privacidade</Link><Button variant="link" className="h-auto p-0 text-[9px] text-footer-ink" onClick={() => window.dispatchEvent(new Event('bella-cookie-settings'))}>Preferências de cookies</Button></div><span>Feito com carinho, para você.</span></div></div></footer>;
}
export function BellaPage() {
 const [openFaq, setOpenFaq] = useState<number | null>(0);
 const [instagramNotice, setInstagramNotice] = useState(false);
 return <><BellaHeader /><main><section className="hero"><img src={hero} className="hero-image" alt="Mulher usando blusa acetinada clara e calça de alfaiataria bege" width={1920} height={1024} fetchPriority="high" /><div className="wrap hero-content"><div className="eyebrow">Leve no vestir. Linda no sentir.</div><h1>Elegância para viver.<br /><em>Liberdade para ser você.</em></h1><p className="hero-copy">Peças que abraçam sua rotina e valorizam sua essência.<br />Conheça a Bella Moda e sinta a diferença de se vestir bem.</p><Button variant="fashion" asChild><a href="#cupom">Quero meu cupom<ArrowRight /></a></Button><div className="hero-note"><Heart size={12} />10% de desconto para começar nossa história.</div></div><div className="hero-caption">BELLA MODA · CASUAL & ELEGANTE</div></section>
 <div className="benefit-bar"><span><ShieldCheck />Seus dados protegidos</span><span><Heart />Cuidado em cada detalhe</span><span><MessageCircle />Atendimento humanizado</span><span><LockKeyhole />Privacidade respeitada</span></div>
 <section className="section"><div className="wrap"><div className="section-heading"><div className="eyebrow text-rose-ink">Histórias que nos inspiram</div><h2>Quem veste, sente a diferença.</h2><p>Mais do que looks. Conexões que fazem parte da nossa história.</p></div><div className="testimonial-grid">{testimonials.map(t => <article className="testimonial" key={t.name}><div className="stars" aria-label="5 estrelas">{Array.from({length:5},(_,i)=><Star key={i} />)}</div><blockquote>“{t.quote}”</blockquote><div className="customer"><span className="avatar-initials">{t.initials}</span><div><strong>{t.name}</strong><small>{t.detail}</small></div></div></article>)}</div><p className="sample-note">Depoimentos ilustrativos, sujeitos à substituição por relatos reais.</p></div></section>
 <section className="section products" id="colecao"><div className="wrap"><div className="section-heading"><div className="eyebrow text-rose-ink">Sua próxima peça favorita</div><h2>Escolhidas para acompanhar você.</h2><p>Do primeiro compromisso ao último brinde. Encontre o seu novo essencial.</p></div><div className="product-grid">{products.map(p => <article key={p.name}><div className="product-photo"><img src={p.image} alt={p.name} width={512} height={768} loading="lazy" />{p.tag && <span className="product-tag">{p.tag}</span>}</div><div className="product-details"><h3>{p.name}</h3><p>{p.price}</p></div><p className="product-sub">{p.detail}</p></article>)}</div><div className="text-center mt-9"><Button variant="fashionOutline" onClick={() => bellaConfig.instagramUrl ? window.open(bellaConfig.instagramUrl,'_blank','noopener,noreferrer') : setInstagramNotice(true)}><Instagram />Ver no Instagram<ArrowRight /></Button>{instagramNotice && <p role="status" className="form-message mt-4">O perfil oficial será divulgado em breve. Cadastre-se para receber as novidades.</p>}<p className="sample-note">Coleção, imagens e preços ilustrativos.</p></div></div></section>
 <section className="values section" id="essencia"><div className="wrap"><div className="section-heading"><div className="eyebrow text-rose-ink">A essência Bella Moda</div><h2>Bonita por fora. Consciente por dentro.</h2><p>O que importa para você também importa para nós.</p></div><div className="values-grid"><div><Leaf /><h3>Escolhas com propósito</h3><p>Valorizamos uma relação mais consciente com a moda. Peças versáteis e atemporais para usar, combinar e amar por mais tempo.</p></div><div><Ruler /><h3>Caimento que acolhe</h3><p>Conforto e elegância caminham juntos. Nosso olhar está nos detalhes que fazem você se sentir bem, sendo exatamente quem é.</p></div><div><MessageCircle /><h3>De mulher para mulher</h3><p>Um atendimento próximo, que escuta e orienta. Da escolha do look às dúvidas sobre tamanho, queremos estar ao seu lado.</p></div></div></div></section>
 <section className="section" id="duvidas"><div className="wrap"><div className="section-heading"><div className="eyebrow text-rose-ink">Pode perguntar</div><h2>Vamos tirar suas dúvidas?</h2></div><div className="faq-wrap">{faqs.map(([q,a],i)=><div className="faq-item" key={q}><Button variant="ghost" className="faq-trigger" aria-expanded={openFaq === i} aria-controls={`faq-${i}`} onClick={()=>setOpenFaq(openFaq === i ? null:i)}>{q}{openFaq === i ? <Minus />:<Plus />}</Button>{openFaq === i && <p className="faq-answer" id={`faq-${i}`}>{a}</p>}</div>)}</div></div></section><LeadCapture /></main><BellaFooter /></>;
}